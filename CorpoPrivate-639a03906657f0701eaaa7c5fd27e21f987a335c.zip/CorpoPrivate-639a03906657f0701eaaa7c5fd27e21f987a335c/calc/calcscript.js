function calculate() {
    var number1 = parseFloat(document.getElementById('number1').value);
    var number2 = parseFloat(document.getElementById('number2').value);
    var operator = document.getElementById('operator').value;
    var result;

    if (isNaN(number1) || isNaN(number2)) {
        alert('Please enter valid numbers');
        return;
    }

    switch (operator) {
        case 'add':
            result = number1 + number2;
            break;
        case 'subtract':
            result = number1 - number2;
            break;
        case 'multiply':
            result = number1 * number2;
            break;
        case 'divide':
            if (number2 != 0) {
                result = number1 / number2;
            } else {
                alert('Division by zero is not allowed');
                return;
            }
            break;
    }

    document.getElementById('result').innerHTML = 'Result: ' + result;
}

function validateInput() {
    var input = document.getElementById('input').value;

    // Check if input is empty
    if (input === '') {
        alert('Input cannot be empty');
        return false;
    }

    // Check if input is a number
    if (isNaN(input)) {
        alert('Input must be a number');
        return false;
    }

    // Check if input is in a certain range
    if (input < 1 || input > 100) {
        alert('Input must be between 1 and 100');
        return false;
    }

    return true;
} // This was the missing closing brace